﻿#pragma once

#include "../../RePlayEngine/Scene/Services/IInputService.h"

#include <array>
#include <filesystem>
#include <string>
#include <string_view>
#include <unordered_map>

#include <windows.h>
#include <Xinput.h>

namespace GameInput
{
    // 名前付き Action / Axis の既定マップ。
    // 数字の VK を呼び出し側へ漏らさず、設定ファイルから差し替えられるようにする。
    struct ActionBinding final
    {
        int keyboard_primary = 0;
        int keyboard_secondary = 0;
        WORD gamepad_button = 0;
        std::string action_map{ "Gameplay" };
    };

    enum class GamepadAxis : int
    {
        None = 0,
        LeftX = 1,
        LeftY = 2,
        RightX = 3,
        RightY = 4,
        LeftTrigger = 5,
        RightTrigger = 6,
    };

    struct AxisBinding final
    {
        int negative_primary = 0;
        int negative_secondary = 0;
        int positive_primary = 0;
        int positive_secondary = 0;
        GamepadAxis gamepad_axis = GamepadAxis::None;
        float dead_zone = 0.18f;
        std::string action_map{ "Gameplay" };
    };

    class InputState final : public ReplayEngine::Scene::IInputService
    {
    public:
        InputState();

        static bool ValidateDeterministicQueries(std::string& error);

        // 1 フレームに 1 回だけ呼ぶ。
        // keyboard_captured=true の間も実デバイス状態は更新し続けるが、Action/Axis へは
        // キーボード入力を公開しない。ImGui の文字入力から Gameplay へ漏らさないため。
        void BeginFrame(bool keyboard_captured, bool mouse_captured) noexcept;
        void SetSuppressed(bool suppressed) noexcept { suppressed_ = suppressed; }
        bool Suppressed() const noexcept { return suppressed_; }

        bool Held(std::string_view action, int player_slot = 0) const noexcept override;
        bool Pressed(std::string_view action, int player_slot = 0) const noexcept override;
        bool Released(std::string_view action, int player_slot = 0) const noexcept override;
        float Axis(std::string_view axis, int player_slot = 0) const noexcept override;
        bool ActionAvailable(std::string_view action) const noexcept override;
        bool AxisAvailable(std::string_view axis) const noexcept override;
        float PointerDeltaX() const noexcept override
        {
            return mouse_captured_ ? 0.0f : mouse_delta_x_;
        }
        float PointerDeltaY() const noexcept override
        {
            return mouse_captured_ ? 0.0f : mouse_delta_y_;
        }
        long PointerScreenX() const noexcept { return mouse_x_; }
        long PointerScreenY() const noexcept { return mouse_y_; }

        // ---- 生デバイス（Action / Axis を定義せずに読む窓口） -----------------

        bool KeyHeld(int key) const noexcept override;
        bool KeyPressed(int key) const noexcept override;
        bool KeyReleased(int key) const noexcept override;
        bool MouseButtonHeld(int button) const noexcept override;
        bool MouseButtonPressed(int button) const noexcept override;
        bool MouseButtonReleased(int button) const noexcept override;
        float PointerX() const noexcept override { return static_cast<float>(mouse_x_); }
        float PointerY() const noexcept override { return static_cast<float>(mouse_y_); }
        float WheelDelta() const noexcept override
        {
            return mouse_captured_ ? 0.0f : wheel_delta_;
        }
        bool GamepadConnected(int player_slot) const noexcept override;
        bool GamepadButtonHeld(int player_slot, int button) const noexcept override;
        bool GamepadButtonPressed(int player_slot, int button) const noexcept override;
        bool GamepadButtonReleased(int player_slot, int button) const noexcept override;
        float GamepadAxisValue(int player_slot, int axis) const noexcept override;
        bool SetGamepadVibration(int player_slot, float low, float high) noexcept override;

        // ホイールは WM_MOUSEWHEEL でしか来ないので、外から積んでもらう。
        void AccumulateWheel(float delta) noexcept { pending_wheel_ += delta; }

        // Saved/Editor/InputBindings.ini。壊れた行は無視し、既定値を残して続行する。
        bool LoadBindings(const std::filesystem::path& path, std::string& error);
        bool SaveBindings(const std::filesystem::path& path, std::string& error) const;
        void ResetDefaultBindings();

        // Project Asset (.replayinput)。missing / broken は false を返し、
        // ResetDefaultBindings() 済みの安全な既定値を維持する。
        static constexpr const char* action_asset_extension = ".replayinput";
        bool LoadActionAsset(const std::filesystem::path& path, std::string& error);
        bool SaveActionAsset(const std::filesystem::path& path, std::string& error) const;
        const std::unordered_map<std::string, ActionBinding>& Actions() const noexcept { return actions_; }
        const std::unordered_map<std::string, AxisBinding>& Axes() const noexcept { return axes_; }
        void SetActionBinding(std::string name, ActionBinding binding) { actions_[std::move(name)] = std::move(binding); }
        void SetAxisBinding(std::string name, AxisBinding binding) { axes_[std::move(name)] = std::move(binding); }

    private:
        struct PadSnapshot final
        {
            XINPUT_STATE current{};
            XINPUT_STATE previous{};
            bool connected = false;
            bool previous_connected = false;
        };

        static bool KeyDown(const std::array<BYTE, 256>& state, int vk) noexcept;
        static bool IsMouseVirtualKey(int vk) noexcept;
        static bool BoundKeyDown(const std::array<BYTE, 256>& state, int vk,
            bool allow_keyboard, bool allow_mouse) noexcept;
        static float NormalizeStick(SHORT value, float dead_zone) noexcept;
        static float NormalizeTrigger(BYTE value, float dead_zone) noexcept;
        static float PadAxis(const XINPUT_GAMEPAD& pad, GamepadAxis axis,
            float dead_zone) noexcept;

        const ActionBinding* FindAction(std::string_view name) const noexcept;
        const AxisBinding* FindAxis(std::string_view name) const noexcept;
        const PadSnapshot* Pad(int player_slot) const noexcept;

        bool ActionDown(const ActionBinding& binding,
            const std::array<BYTE, 256>& keyboard,
            const PadSnapshot* pad, bool allow_keyboard, bool allow_mouse) const noexcept;
        float AxisValue(const AxisBinding& binding,
            const std::array<BYTE, 256>& keyboard,
            const PadSnapshot* pad, bool allow_keyboard) const noexcept;

        std::array<BYTE, 256> keyboard_current_{};
        std::array<BYTE, 256> keyboard_previous_{};
        std::array<PadSnapshot, XUSER_MAX_COUNT> pads_{};
        std::unordered_map<std::string, ActionBinding> actions_;
        std::unordered_map<std::string, AxisBinding> axes_;
        bool keyboard_captured_ = false;
        bool previous_keyboard_captured_ = false;
        bool mouse_captured_ = false;
        bool previous_mouse_captured_ = false;
        bool mouse_initialized_ = false;
        bool suppressed_ = false;
        long mouse_x_ = 0;
        long mouse_y_ = 0;
        float mouse_delta_x_ = 0.0f;
        float mouse_delta_y_ = 0.0f;
        float wheel_delta_ = 0.0f;
        float pending_wheel_ = 0.0f;
    };
}
