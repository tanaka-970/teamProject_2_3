﻿#pragma once

#include "../../Object/Component/Component.h"
#include "../../Reflection/Property/PropertyDesc.h"
#include "../../Rendering/Shaders/ShaderAsset.h"
#include "../../UI/Effects/UIEffect.h"

#include <DirectXMath.h>

#include <cstdint>
#include <vector>

namespace ReplayEngine::Assets { class AssetDatabase; }

namespace ReplayEngine::Components
{
    class ScreenEffectStackComponent final : public Core::Component
    {
        REPLAY_COMPONENT_BODY(ScreenEffectStackComponent)

    public:
        ScreenEffectStackComponent();

        const std::vector<Reflection::PropertyDesc>* DynamicProperties()
            const noexcept override;
        void OnSerialize(Reflection::PropertyBag& output) const override;
        void OnDeserialize(const Reflection::PropertyBag& input) override;
        void OnPropertyChanged(const char* property_name) override;

        bool HasActiveEffects() const noexcept;
        bool HasActiveEffects(const Assets::AssetDatabase* database) const noexcept;
        DirectX::XMFLOAT4 ExpandBounds(float target_width,
            float target_height) const noexcept;
        DirectX::XMFLOAT4 ExpandBounds(float target_width, float target_height,
            const Assets::AssetDatabase* database) const noexcept;
        const std::vector<UI::UIEffect>& EffectiveEffects(
            const Assets::AssetDatabase* database) const noexcept;

        // ShaderCatalog の Schema を同期し、Custom Effect の Property を
        // DynamicProperties() へ追加する。GPU や AssetDatabase は保持しない。
        void SetCustomShaderSchema(std::size_t effect_index,
            Rendering::ShaderPropertySchemaRef schema);

        bool enabled = true;
        // Stack 全体へ掛ける矩形/楕円/画像マスク範囲。
        UI::UIEffectRegion effect_region;
        // false の既存 Scene は inline 値をそのまま使う。Preset 参照は追加の選択肢。
        bool use_preset = false;
        Reflection::AssetReference effect_preset;
        int effect_count = 0;
        std::vector<UI::UIEffect> effects;

        enum ApplyStage : int
        {
            AfterPostProcess = 0,
            BeforePostProcess = 1,
        };

        // 既定は PostProcess 後。UI 描画より前に適用される。
        int apply_stage = AfterPostProcess;

        enum TargetMode : int
        {
            WholeScreen = 0,
            BackgroundOnly = 1,
            RenderingLayerMask = 2,
        };

        // 既定値0は従来の画面全体。既存Sceneの見た目を変えない。
        int target_mode = WholeScreen;
        // RenderingLayerMask 時だけ使用。bit N が Rendering Layer N。
        int target_rendering_layer = 0;

    private:
        void ResizeEffects();
        void RebuildDynamicProperties();

        std::vector<Reflection::PropertyDesc> dynamic_properties_;
        std::vector<Rendering::ShaderPropertySchemaRef> custom_schemas_;
    };
}
