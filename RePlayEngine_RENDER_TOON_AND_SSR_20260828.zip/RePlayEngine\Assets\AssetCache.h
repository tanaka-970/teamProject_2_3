﻿#pragma once

#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

namespace ReplayEngine::Assets
{
    enum class AssetKind : std::uint32_t
    {
        Unknown,
        Model,
        Image,
        Audio,
        Shader,
        Scene,
        Material,

        // Lua / C# のスクリプトアセット。
        //
        // 必ず末尾へ足すこと。値は .replaydb へ整数として書かれているので、
        // 途中へ挿入すると既存の Asset の種別が別のものへ化ける。化けました
        Script,

        // .replaysceneflow。既存値を壊さないよう必ず末尾。
        SceneFlow,

        // .ttf / .otf / .ttc。resources/fonts の起動時自動登録と、
        // UIText のフォント欄を「フォントだけ」に絞るために使う。
        // 既存値を壊さないよう必ず末尾。
        Font,

        // .replaymotion / .replaycomp。既存値を壊さないよう必ず末尾。
        Motion,

        // .replayloc。既存値を壊さないよう必ず末尾。
        Localization,

        // .replayeffect。UI / Model / Screen 共通 Effect Preset。必ず末尾。
        EffectPreset,

        // .replayinput。Action / Binding のプロジェクト Asset。必ず末尾。
        InputAction,

        // .replayatlas。名前付き Sprite Region / Pivot を持つ。既存値を壊さないよう必ず末尾。
        SpriteAtlas,

        // .replaycomp。Motion と分けて Inspector の候補を正確にする。必ず末尾。
        Composition,

        // .replayeasing。Motion のイージング素材。既存値を壊さないよう必ず末尾。
        EasingCurve
    };

    struct AssetCacheEntry
    {
        std::filesystem::path source_path;
        std::filesystem::path cache_path;
        std::uint64_t source_fingerprint = 0;
        std::uint32_t format_version = 0;
        AssetKind kind = AssetKind::Unknown;
    };

    // 各インポーターが生成したバイナリを共通形式で保存するキャッシュ。
    // FBX、glTF、画像などの個別ローダーには依存しない。
    class AssetCache final
    {
    public:
        explicit AssetCache(std::filesystem::path root =
            std::filesystem::path("resources") / ".replay_cache");

        bool Store(const std::filesystem::path& source, AssetKind kind,
            std::uint32_t format_version, const std::vector<std::uint8_t>& payload,
            AssetCacheEntry& entry, std::string& error) const;
        bool Load(const std::filesystem::path& source, AssetKind kind,
            std::uint32_t format_version, std::vector<std::uint8_t>& payload,
            AssetCacheEntry& entry, std::string& error) const;
        bool StoreSourceFile(const std::filesystem::path& source, AssetKind kind,
            AssetCacheEntry& entry, std::string& error) const;

    private:
        bool Describe(const std::filesystem::path& source, AssetKind kind,
            std::uint32_t format_version, AssetCacheEntry& entry,
            std::string& error) const;

        std::filesystem::path root_;
    };
}
